import java.util.Scanner;
import java.util.Random;
import java.util.concurrent.*;

public class SpillRobot extends Spill{

  public SpillRobot(CountDownLatch latch){
    super(latch);
  }

  /*
  Setter opp objekt av type SprillerRobot som returneres til SpillKontroll
  */


  @Override
  public Spiller settOppSpiller(int antallTR){
    String[] robotnavn = new String[]{"Robot", "Robot1", "Robot2","R"};
    Terreng terreng = new Terreng();
    Sted start = terreng.hentStart();
    Scanner input = new Scanner(System.in);
    Terminal terminal = new Terminal(input);
    Robot robot = new Robot();
    System.out.println("----------------------------------");
    System.out.println("----------------------------------");
    System.out.println("Spillet startet! Velg et navn for robot. ");  // velger navn for robot for aa ha bedre kontroll i spillet
    String spillernavn = input.next();
    Spiller spiller2 = new SpillerRobot(start, spillernavn, terreng, robot, antallTR, latch);


    return spiller2;
  }

/*  public void startSpil(int antallTR){
    //---spiller gjoer trekk uavhengig av andre spillere
    int teller1 = 0;

    while (teller1 != antallTR){
    spiller2.nyttTrekk();
      }

      teller1 ++;
  }*/


}

import java.util.*;
import java.util.concurrent.*; // importerer med * som det ble anbefalt i repitisjonskurset


/*
Her brukte jeg Oppgave 5 som utgangspunkt. Det er flere maater man ka loese:

1. (Alternativt, ikke dette programmet) ga gjennom spillerliste og starte traa for hver spiller.
  starte traaden som ville gaa i loop for antall trekk for spill.
  alle traadene utføres uavhelig av hverandre.
  Jeg slett med aa faa pent utskrift per trekk  --> per spiller. Man kunne utforske static syncronization, men da
  maatte jeg skrive om mye av koden.
  CountDountLatch soerget for at main-traa ventet paa at alle traadene var ferdige
  Resultatet av spillet var riktig. Jeg satt laaser for Stattkiste og Terminal/ Robot.
  Allikevel synes jeg at det er behagelig aa ha oversiktlig interaksjon med brukeren, derfor laget denne versjonen som
  i utgangspunktet gjoer akkuratt det samme som i oppgave 5.

2. (denne versjonen) bruker CountDownLatch og join() slik at "trekkene" gaar etter hverandre. Tror at hensikten var at
  spillere gjoer sitt trekk etter hverandre, ikke uavhengig av hverandre. Uavhengighet er lur kun for spill med roboter, ikke med menneskelig brukere.
  Jeg beholdte laasene, men de er ikke trengs i denne versjonen siden tradene er joinet og venter paa hvaerandre.



*/

public class SpillKontroll{

  public static void main(String [] args) throws InterruptedException {



    ArrayList<Integer> brukerValg = new ArrayList<>();  // skal lagre valg fra brukeren for aa etablere spillere etterpaa
    ArrayList<Spiller> spillere = new ArrayList<>();    // skal lagre etablerte brukere hit
    String[] valgarray = new String []{"0", "1"};       // brukes i valg mellom to varianter
    Scanner scanner = new Scanner(System.in);




    System.out.println("-------------------------");
    System.out.println("Velkommen til Fantasiverden.");
    System.out.println("Velg antall spillere?");

// etablerer spillere og lagrer dem i ArrayList
    int antallSpillere = lesInput();
    CountDownLatch latch = new CountDownLatch(antallSpillere); // hver spiller skla vaere en traa
    int teller = 0;
    while (teller !=antallSpillere){
      System.out.println("Hvem skal spille: 0 - robot, 1 - bruker?");
      int valg;
      valg = lesInput();
      while(check(valgarray, valg)!= true){
        System.out.println("Velg mellom 0 og 1 for aa starte spillet.");
        valg = lesInput();
      }
      brukerValg.add(valg);
      teller ++;
    }
    System.out.println("Velg antall trekk for dette spillet: ");
    int antallTrekkSpill = lesInput();

    if (brukerValg.size() > 0){
      for(int valg: brukerValg){
        if(valg == 0){
          Spill spill1 = new SpillRobot(latch);
          Spiller spiller1 = spill1.settOppSpiller(antallTrekkSpill);
          spillere.add(spiller1);
        }
        if (valg == 1){
          Spill spill2 = new SpillBruker(latch);
          Spiller spiller2 = spill2.settOppSpiller(antallTrekkSpill);
          spillere.add(spiller2);}
        }
    }

// lager traader
long starttid = System.currentTimeMillis();
int teller1 = 0;

    while (teller1 != antallTrekkSpill){
      System.out.println("----------------------------------");
      System.out.println("Tekk : "+ (teller1 +1));
      if (spillere.size()>0){
        for(int i = 0; i < spillere.size();i++){
          Thread traa = new Thread(spillere.get(i));
          traa.start();
          try{
            traa.join();
          } catch (InterruptedException e){
            e.printStackTrace();
          }

          System.out.println("------");

        }


      }

      teller1 ++;
    }

    try{
      latch.await();
    } catch (InterruptedException e){
      e.printStackTrace();
    }

    System.out.println("-------------------------------");
    System.out.println("-------------------------------");
    System.out.println("Resultat for dette spillet: ");
    Spiller vinner = finnVinneren(spillere);
    System.out.println("Vinneren er: ");
    System.out.println("Spiller : " + vinner.hentNavn());
    System.out.println("Med formue på: " + vinner.hentFormue());

    long slutttid = System.currentTimeMillis();
    long tidbrukt = slutttid - starttid;
    System.out.println("Tiden brukt: " + tidbrukt);


  }




  public static  int lesInput(){
    Scanner scanner1 = new Scanner(System.in);
    int valg1 = -1;

    while(valg1 < 0){
      try{
        valg1 = scanner1.nextInt();

      }
      catch(InputMismatchException ex){
        System.out.println("Proev igjen. Tast inn et tall ");
        scanner1.next();
      }
    }


    return valg1;
  }

  private static boolean check(String[] valg, int input){
    boolean kontroll = false;
    int lengde = valg.length;
    int [] nyarray = new int[lengde];
    for(int i =0; i<lengde; i++){
      nyarray[i]=i;

    }
    for(int j=0; j< nyarray.length; j++ ){
      if (j == input){
        kontroll = true;}
    }

    return kontroll;
  }

  private static Spiller finnVinneren(ArrayList<Spiller> pSpillere){
    Spiller vinneren = pSpillere.get(0);
    for(int i= 0; i< pSpillere.size(); i++){
      if(pSpillere.get(i).compareTo(vinneren)== 1){
        vinneren = pSpillere.get(i);
      }

    }
    return vinneren;
  }


}

/*
Siden vi har to typer av spillere, velger aa lage klassen Spiller som abstract
Menneskelig bruker skal spille gjennom klasse SpillerBruker, mens robot - SpillerRobot
*/
import java.util.concurrent.*;

abstract class Spiller extends Thread implements Comparable<Spiller> {

  protected  String navn;
  protected  Sted startSted;
  protected  Terreng terreng;
  protected  int formue = 0;
  protected  int antallTrekkforSpiller;
  protected CountDownLatch latch;


  public Spiller (Sted start, String navn, Terreng ter, int antallTrekk, CountDownLatch latch){
    startSted = start;
    this.navn = navn;
    terreng = ter;
    antallTrekkforSpiller = antallTrekk;
    this.latch = latch;


  }


  public void nyttTrekk(){}



  public int hentFormue(){
    return formue;

  }

  public String hentNavn(){
    return navn;

  }

  @Override
    public int compareTo(Spiller annen) {
      Integer denneFormue = new Integer(this.hentFormue());
      Integer annenFormue = new Integer(annen.hentFormue());
      if (denneFormue.compareTo(annenFormue) > 0) {
          return 1;
      }
      else if (denneFormue.compareTo(annenFormue) < 0) {
          return -1;
      }
      else return 0;
  }


  @Override
  public void run(){

      System.out.println("Spiller: " + navn);
      this.nyttTrekk();

      latch.countDown();


  }


}

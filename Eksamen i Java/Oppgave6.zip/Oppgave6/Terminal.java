import java.util.*;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;

/*

Her maa jeg bruke samme laas for begge metodene for aa sikre at valgliste ikke blir blandet med valglisteen til en annen traa
*/

public class Terminal implements Brukergrensesnitt{

  Scanner scanner;
  Lock laas;



  public Terminal(Scanner sc){
    scanner = sc;
    laas = new ReentrantLock();
  
  }

  @Override
  public void giStatus(String status){
    laas.lock();
    try{
      if (status != null){
        System.out.println(status);
      }
    } finally{
      laas.unlock();
    }



  }



  @Override
  public int beOmKommando(String spoersmaal, String[] alternativer){

    laas.lock();
    int valg = -1;
    try{
      System.out.println();
      int indeks = 0;

      if (spoersmaal != null){
        System.out.println(spoersmaal);
      }

      for (int i = 0; i< alternativer.length; i++){
        if(alternativer[i] != null){
          System.out.println(indeks + ": " + alternativer[i]);
          indeks ++;
        }

      }
      while(valg < 0){
        try{
          valg = scanner.nextInt();

        }
        catch(InputMismatchException ex){
          System.out.println("Proev igjen. Tast inn et tall ");
          scanner.next();
        }
      }
    } finally{
      laas.unlock();
    }


    return valg;

  }


}

/*
Her valgte jeg aa bruke LinkedList i haap om at den hadde next() and previous() og jeg hadde lyst til aa
proeve  denne siden vi jobbet saa mye ned vaare egne lenkede lister hele semester.
Men jeg ser at jeg kunne bruke ArrayList her ogsaa
LinkedLister er mer effektiv med tanke paa minne. ArrayList er raskere. Hvis vi velger
flere tusen trekk, er ArrayList bedre egnet for spillet.

*/

import java.util.*;
import java.util.Scanner;
import java.io.*;


public class Terreng{
  LinkedList<Sted> stedliste;

  public Terreng(){
    stedliste = new LinkedList<Sted>();
    lesFraFil();
    settNesteAll();
  }

  private void lesFraFil(){
    File f = new File("steder.txt");
    Scanner fil = null;
    try {
      fil = new Scanner(f);
    } catch (FileNotFoundException e) {
      System.out.println("Filen er ikke funnet!");
    }

    String linje = "";
    while(fil.hasNextLine()){
      linje = fil.nextLine();
      Sted nySted = new Sted(linje);
      Skattkiste nykiste = new Skattkiste();
      nykiste.fyllSkattkiste();
      nySted.settSkattKiste(nykiste);
      stedliste.add(nySted);

    }

  }

//-- setter referanser til neste sted for alle steder --
//-- terreng er gjort til syklisk ----------------------
    public void settNesteAll(){
      for(int i = 0; i < stedliste.size()-1; i++){
        stedliste.get(i).settNeste(stedliste.get(i+1));
      }
      stedliste.get(stedliste.size()-1).settNeste(stedliste.getFirst());

    }

//---- henter tilfeldig sted -----------------------------
    public Sted hentStart(){
      Random r = new Random();
      int tillfeldigSted = r.nextInt(stedliste.size());
      Sted start = stedliste.get(tillfeldigSted);
      return start;
    }

    public LinkedList<Sted> hentStedListe(){
      return stedliste;
    }



}

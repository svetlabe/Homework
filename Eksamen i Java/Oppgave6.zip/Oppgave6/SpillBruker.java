import java.util.Scanner;
import java.util.Random;
import java.util.concurrent.*;

/*
Setter opp objekt av type SprillerBruker som returneres til SpillKontroll
*/

public class SpillBruker extends Spill{
  public SpillBruker(CountDownLatch latch){
    super(latch);
  }


  @Override
  public Spiller settOppSpiller(int antallTB){
    Terreng terreng = new Terreng();
    Sted start = terreng.hentStart();
    Scanner input = new Scanner(System.in);
    Terminal terminal = new Terminal(input);
    System.out.println("----------------------------------");
    System.out.println("----------------------------------");
    System.out.println("Spillet startet! Velg et navn for brukeren. ");
    String spillernavn = input.next();
    Spiller spiller1 = new SpillerBruker(start, spillernavn, terreng, terminal, antallTB, latch);


    return spiller1;
  }

/*  public void startSpil(int antallTB){
    //---spiller gjoer trekk uavhengig av andre spillere
    int teller = 0;

    while (teller != antallTB){
    spiller2.nyttTrekk();
      }

      teller1 ++;
  }*/
}

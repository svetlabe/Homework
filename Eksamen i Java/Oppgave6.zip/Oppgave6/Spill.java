import java.util.concurrent.*;
abstract class Spill{

/*
Vi forskjellige typer av spill, lager derfor Spill som abstrakt klasse
Alle objekter Spill maa implementere abstrakt metode startSpill() som styrer spillet
*/
CountDownLatch latch;
  public Spill(CountDownLatch latch){
    this.latch = latch;
  }

  abstract Spiller settOppSpiller(int antallTrekk);
}

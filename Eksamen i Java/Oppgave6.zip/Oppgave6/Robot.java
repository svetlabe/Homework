import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;

/*
Jeg har fjernet spoersmaal til Robot, kun valget som skal srives ut paa skjermen

beskytter utskrift
*/
public class Robot implements Brukergrensesnitt{

  Lock laas;
  public Robot(){
    laas = new ReentrantLock();
  }


  @Override
  public void giStatus(String status){
    laas.lock();
    try{
      if (status != null){
        System.out.println(status);
      }
    } finally{
      laas.unlock();
    }


  }



  @Override
  public int beOmKommando(String spoersmaal, String[] alternativer){
    int valg;
    laas.lock();
    try{
      Random r = new Random();
      int indeks = 0;
      System.out.println();
      if (spoersmaal != null){
        System.out.println(spoersmaal);
      }

      for (int i = 0; i< alternativer.length; i++){
      

      }
      valg = r.nextInt(alternativer.length);
      if (alternativer[valg] != null){
        System.out.println("Jeg velger: " + alternativer[valg]);
        System.out.println();
      }
    } finally{
      laas.unlock();
    }



    return valg;

  }
}

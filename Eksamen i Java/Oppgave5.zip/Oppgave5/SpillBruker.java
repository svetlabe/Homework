import java.util.Scanner;
import java.util.Random;

/*
Setter opp objekt av type SprillerBruker som returneres til SpillKontroll
*/

public class SpillBruker extends Spill{

  @Override
  public Spiller startSpill(){
    Terreng terreng = new Terreng();
    Sted start = terreng.hentStart();
    Scanner input = new Scanner(System.in);
    Terminal terminal = new Terminal(input);
    System.out.println("----------------------------------");
    System.out.println("----------------------------------");
    System.out.println("Spillet startet! Velg et navn for brukeren. ");
    String spillernavn = input.next();
    Spiller spiller1 = new SpillerBruker(start, spillernavn, terreng, terminal);


    return spiller1;
  }
}

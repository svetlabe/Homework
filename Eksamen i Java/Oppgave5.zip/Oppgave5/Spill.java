abstract class Spill{

/*
Vi har forskjellige typer av spill, lager derfor Spill som abstrakt klasse
Alle objekter Spill maa implementere abstrakt metode startSpill() som styrer spillet
*/
  abstract Spiller startSpill();
}

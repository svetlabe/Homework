import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;


public class Skattkiste {
  ArrayList<Gjenstand> kiste;
  int fullkiste;
/*
Vi bruker Skattkiste både for kister på steder og for ryggsekk hos en spiller.
ryggsekk er tom i starten av Spillet
kiste på et sted fylles med alle elementer fra fil gjenstander.txt; Kistene er fulle på hvert sted i starten av spillet.

Bruker ArrayList for aa gi mulighet til aa selge gjenstander fra ryggsekk på hvert sted selv om kisten er full.
Ryggsekk er også magisk og kan inneholde ubegrenset antall gjenstander. Det er opptil spilleren å passe på å selge gjenstander
slik at man kan få formue.
*/


  public Skattkiste(){
    kiste = new ArrayList<>();
  }

//-- metode leser gjenstander fra fil og fyller kisten
  public void fyllSkattkiste(){

    File f = new File("gjenstander.txt");

    Scanner fil = null;
    try {
      fil = new Scanner(f);
    } catch (FileNotFoundException e) {
      System.out.println("Filen er ikke funnet!");
    }

    String linje = "";
    while (fil.hasNextLine()) {
      linje = fil.nextLine();

      String[] delt = linje.split(" ");
      String pBeskrivelse = delt[0];
      int pPris = Integer.parseInt(delt[1]);
      Gjenstand nyGjenstand = new Gjenstand(pBeskrivelse, pPris);
      kiste.add(nyGjenstand);

    }
    fullkiste = kiste.size();


  }

//---- bruker denne metoden i kommunikasjon med spilleren ---
//---- viser hva som finnes i kiste/ rygsekken --------------
  public String visInnholdKiste(){
    String innhold = "";

    if (kiste.size()>0){
      for (int i = 0; i< kiste.size(); i++){
        innhold += " " + kiste.get(i).toString() + ", ";
        innhold.substring(0, innhold.length() - 1);
        //System.out.println(kiste.get(i));
      }

    } else{
        System.out.println("Ingen gjenstander.");
      }

    return innhold;

    }

    public void tomKiste(){
      kiste.clear();
    }

// --- denne metoden er brukt i valg av skatt fra kiste; tilfelldig valg ---
    public Gjenstand taUt(){
      Random random = new Random();
      int tilfeldigIndeks = random.nextInt(kiste.size());
      Gjenstand tattGjenstand = kiste.remove(tilfeldigIndeks);
      return tattGjenstand;
    }

    public void leggTil(Gjenstand nyGjenstand){
      kiste.add(nyGjenstand);
    }

//----- Brukes i kommunikasjon med spilleren, slik at spilleren kan ta beslutning ------
    public String kisteStatus(){
      String status;
      if(kiste.size() == 0){
        status = "Her er det ingen skatt. Kisten er tom.";
      } else if (kiste.size() == fullkiste){
        status = "Her er det mange skatter! Kisten er full. ";
      } else{
        status = "Du kan finne en skatt her.";
      }

      return status;

    }

    public ArrayList<Gjenstand> hentKiste(){
      return kiste;
    }

//---- denne metoden tar ut gjenstand med høyste verdi, øker verdi med tilfelid tillegg siden dette er magisk skattkiste :)---
//---- jeg har valgt at prisen som spilleren får tilbake for gjenstander skal være høyere enn han fikk tidligere og at tillegget varierer mellom 0 og 20.
// Jeg antar at variasjon på innil 20 ikke er veldig forskjellig fra opprinnelig pris

    public Gjenstand taUtAvRyggsekk(){
      Random r2 = new Random();
      int tilfeldigTillegg = r2.nextInt(20);
      Gjenstand tattGjenstand = kiste.remove(finnMaxIndeks());
      tattGjenstand.endrePris(tilfeldigTillegg);
      return tattGjenstand;
    }

//---- brukes i metode for å ta ut gjenstand fra ryggsekken ---
    public int finnMaxIndeks(){
      Gjenstand maks = kiste.get(0);
      int maksIndeks = 0;
      for(int i= 0; i< kiste.size(); i++){
        if(kiste.get(i).compareTo(maks)== 1){
          maks = kiste.get(i);
          maksIndeks = i;
        }

      }
      return maksIndeks;

    }



}



public class Sted{

  private Sted neste;
  private String beskrivelse;
  private Skattkiste skattkiste;

  public Sted(String beskr){
    beskrivelse = beskr;

  }

  public void settNeste(Sted nesteSted){
    neste = nesteSted;
  }

  public void settSkattKiste(Skattkiste kiste){
    skattkiste = kiste;
  }

  public Skattkiste hentSkattKiste(){
    return skattkiste;
  }

  public Sted gaaVidere(){
    return neste;
  }

  public String toString(){
    return beskrivelse;
  }


}

import java.util.*;
//import java.util.ArrayList;


/*
Valg av datastruktur:
ArrayList: for aa ikke begrense antall spillere.

1. definere antall brukere
2. etablere spillere
3. loop for antall trekk som inneholder loop for her bruker

Man kunne selvfoelgelig lage kortere main-metode og flytte andre statiske metode til en egen klass som vill
passet paa spillet, men da ville jeg maatte opprette enda en fil siden det er forskjellig typer spillere som er i spillet.

*/

public class SpillKontroll{

  public static void main(String [] args){
    ArrayList<Integer> brukerValg = new ArrayList<>();  // skal lagre valg fra brukeren for aa etablere spillere etterpaa
    ArrayList<Spiller> spillere = new ArrayList<>();    // skal lagre etablerte brukere hit
    String[] valgarray = new String []{"0", "1"};       // brukes i valg mellom to varianter
    Scanner scanner = new Scanner(System.in);


    System.out.println("-------------------------");
    System.out.println("Velkommen til Fantasiverden.");
    System.out.println("Velg antall spillere?");

// etablerer spillere og lagrer den i ArrayList
    int antallSpillere = lesInput();
    int teller = 0;
    while (teller !=antallSpillere){
      System.out.println("Hvem skal spille: 0 - robot, 1 - bruker?");
      int valg;
      valg = lesInput();
      while(check(valgarray, valg)!= true){
        System.out.println("Velg mellom 0 og 1 for aa starte spillet.");
        valg = lesInput();
      }
      brukerValg.add(valg);
      teller ++;
    }
    System.out.println("Velg antall trekk for dette spillet: ");
    int antallTrekkSpill = lesInput();

    if (brukerValg.size() > 0){
      for(int valg: brukerValg){
        if(valg == 0){
          Spill spill1 = new SpillRobot();
          Spiller spiller1 = spill1.startSpill();
          spillere.add(spiller1);
        }
        if (valg == 1){
          Spill spill2 = new SpillBruker();
          Spiller spiller2 = spill2.startSpill();
          spillere.add(spiller2);}
        }
    }


//---hver bruker gjoer trekk etter hverandre
    int teller1 = 0;

    while (teller1 != antallTrekkSpill){
      System.out.println("----------------------------------");
      System.out.println("Tekk : "+ (teller1 +1));
      if (spillere.size()>0){
        for(int i = 0; i < spillere.size();i++){
          Spiller spilleriSpill = spillere.get(i);
          System.out.println("Spiller :" + spilleriSpill.hentNavn());
          spilleriSpill.nyttTrekk();
          System.out.println("------");

        }

      }
      teller1 ++;


    }
    System.out.println("-------------------------------");
    System.out.println("-------------------------------");
    System.out.println("Resultat for dette spillet: ");
    Spiller vinner = finnVinneren(spillere);
    System.out.println("Vinneren er: ");
    System.out.println("Spiller : " + vinner.hentNavn());
    System.out.println("Med formue på: " + vinner.hentFormue());



  }

  public static  int lesInput(){
    Scanner scanner1 = new Scanner(System.in);
    int valg1 = -1;

    while(valg1 < 0){
      try{
        valg1 = scanner1.nextInt();

      }
      catch(InputMismatchException ex){
        System.out.println("Proev igjen. Tast inn et tall ");
        scanner1.next();
      }
    }


    return valg1;
  }

  private static boolean check(String[] valg, int input){
    boolean kontroll = false;
    int lengde = valg.length;
    int [] nyarray = new int[lengde];
    for(int i =0; i<lengde; i++){
      nyarray[i]=i;

    }
    for(int j=0; j< nyarray.length; j++ ){
      if (j == input){
        kontroll = true;}
    }

    return kontroll;
  }

  private static Spiller finnVinneren(ArrayList<Spiller> pSpillere){
    Spiller vinneren = pSpillere.get(0);
    for(int i= 0; i< pSpillere.size(); i++){
      if(pSpillere.get(i).compareTo(vinneren)== 1){
        vinneren = pSpillere.get(i);
      }

    }
    return vinneren;
  }


}

public class SpillerBruker extends Spiller{

  private Terminal terminal;
  Skattkiste ryggsekk;
  String[] valg1 = new String[]{"Selge en gjenstand fra ryggsekken.", "Ta skatt fra kisten.", "Gaa videre.", "Avslutt spill."};
  String[] valg2 = new String []{"Ta skatt fra kisten.", "Gaa videre.", "Avslutt spill."};
  String[] valg3 = new String []{"Bli igjen på dette stedet, her er mange skatter igjen","Gaa videre.", "Avslutt spill."};
  String[] valg4 = new String []{"Gaa videre.", "Avslutt spill."};
  String spoersmaal = "Hva vil du gjøre nå?";
  Sted currentSted;
  Sted nesteSted;


  public SpillerBruker(Sted start, String navn, Terreng ter, Terminal t){
    super(start, navn, ter);
    terminal = t;
    ryggsekk = new Skattkiste();    // oppretter tom ryggsekk
    nesteSted = start.gaaVidere();
    currentSted = start;

  }

/*
Reglene er som følger:
- man har 4 valg: selge fra ryggsekken, hente skatt, gaa videre, avslutte
- hvis rygsekken er tom og man velger aa selge, faar man en mulighet til aa gjøre et valg i samme trekk
-- etterpaa faar man 3 valg: selge, gaa videre, avslutte
- hvis man vekger aa selge, faar man videre valg: bli igjen paa dette stedet, gaa videre, avslutte
-- brukeren kan avbryte spillet, spillet er ikke ferdig og resultatet ikke skal printes
-- man kan velge om  aa gaa videre eller bli igjen paa stedet
*/
@Override
public void nyttTrekk(){

  terminal.giStatus( currentSted.toString()); // viser hvor vi er i spillet
  terminal.giStatus(currentSted.hentSkattKiste().kisteStatus()); // viser status paa kiste(tom eller ikke)


  int kommando1 = terminal.beOmKommando(spoersmaal, valg1); // ber om valg (selge, ta fra kiste, gaa, avslutt)

  while(check(valg1, kommando1)!= true){
    terminal.giStatus("Feil kommando. Proev igjen");
    kommando1 = terminal.beOmKommando(spoersmaal, valg1);
  }

  if(kommando1 == 0){                                      // hvis spiller vil selge
    if(ryggsekk.kiste.size()> 0 ){                        // hvis ryggsekk ikke er tom
      Gjenstand tattUtAvSekken = ryggsekk.taUtAvRyggsekk(); // tar ut gjenstand med hoeyest verdi
      currentSted.hentSkattKiste().leggTil(tattUtAvSekken); // legger til kiste med  salgsverdi
      formue += tattUtAvSekken.hentPris();
      terminal.giStatus("Gratulerer! Du har solgt " + tattUtAvSekken);
      terminal.giStatus("Din formue er: " + formue);
      terminal.giStatus("Ryggsekken inneholder: ");
      terminal.giStatus(ryggsekk.visInnholdKiste());
      valg2();                                            // ber om valg2 (ta fra kiste, gaa videre eller avslutt)

    } else {
      terminal.giStatus("Du kan ikke selge nå. Ryggsekken er tom.");
      kommando1 = terminal.beOmKommando(spoersmaal, valg1); // spilleren faa en sjanse til valg1
    }
  }
  if(kommando1 == 1){                                // brukeren vil ta fra kiste

    if(currentSted!= null){
      if(currentSted.hentSkattKiste().kiste.size() > 0 ){
        Gjenstand fantSkatt = currentSted.hentSkattKiste().taUt();
        ryggsekk.leggTil(fantSkatt);
        terminal.giStatus("Gratulerer! Du fant " + fantSkatt);
        terminal.giStatus("Ryggsekken inneholder: ");
        terminal.giStatus(ryggsekk.visInnholdKiste());

        valg3();                          // ber om valg(bli igjen paa stedet, gaa videre eller avslutt)


      }else {
        System.out.println("Du er ikke på et sted i spillet.");
      }
    }


  }

  if (kommando1 == 2){
    currentSted = nesteSted;
    nesteSted = currentSted.gaaVidere();



  }

  if(kommando1 == 3){
    terminal.giStatus("Spillet er avbrutt.");
    System.exit(0);
  }

}

//ta skatt, gaa videre eller avslutt
public void valg2(){
  int kommando2 = terminal.beOmKommando(spoersmaal, valg2);
  while(check(valg2, kommando2)!= true){
    terminal.giStatus("Feil kommando. Proev igjen");
    kommando2 = terminal.beOmKommando(spoersmaal, valg2);
  }
  if(kommando2 == 0){
    if(currentSted.hentSkattKiste().kiste.size() > 0 ){
      Gjenstand fantSkatt2 = currentSted.hentSkattKiste().taUt();
      ryggsekk.leggTil(fantSkatt2);
      terminal.giStatus("Gratulerer! Du fant " + fantSkatt2);
      terminal.giStatus("Ryggsekken inneholder: ");
      terminal.giStatus(ryggsekk.visInnholdKiste());
    }else{
      terminal.giStatus("Kisten er tom. Finn et annet sted.");
      int kommando3 = terminal.beOmKommando(spoersmaal, valg4);

      if(kommando3 == 0){
        currentSted = nesteSted;
        nesteSted = currentSted.gaaVidere();
      }
      if (kommando3 == 1){
        terminal.giStatus("Spillet er avbrutt.");
        System.exit(0);
      }
    }
    valg3();
  }
  if(kommando2 == 1){
    currentSted = nesteSted;
    nesteSted = currentSted.gaaVidere();
  }
  if (kommando2 == 2){
    terminal.giStatus("Spillet er avbrutt.");
    System.exit(0);
  }
}

// valg om aa bli igjen eller gaa videre
public void valg3(){

  int kommando3 = terminal.beOmKommando(spoersmaal, valg3);
  while(check(valg3, kommando3)!= true){
    terminal.giStatus("Feil kommando. Proev igjen");
    kommando3 = terminal.beOmKommando(spoersmaal, valg3);
  }
  if (kommando3 == 0){
    return;
  }
  if (kommando3 == 1){
    currentSted = nesteSted;
    nesteSted = currentSted.gaaVidere();
  }

}

// bruker for aa sjekke om valget er riktig
private boolean check(String[] valg, int input){
  boolean kontroll = false;
  int lengde = valg.length;
  int [] nyarray = new int[lengde];
  for(int i =0; i<lengde; i++){
    nyarray[i]=i;

  }
  for(int j=0; j< nyarray.length; j++ ){
    if (j == input){
      kontroll = true;}
  }

  return kontroll;
}


}

import java.util.Scanner;

import java.util.Random;

  // Her er det spill med brukeren som spiller.
  // for aa spille med robot, se fil SpillRobot

  public class SpillRobotVeiValg extends Spill{


    @Override
    public void startSpill(){
      Terreng terreng = new VeiValgTerreng();
      Sted start = terreng.hentStart();
      Scanner input = new Scanner(System.in);
      Robot robot = new Robot();
      System.out.println("----------------------------------");
      System.out.println("----------------------------------");
      System.out.println("Spillet startet! Velg et navn. ");  // velger navnet for robot selv for aa ha bedre kontroll i oppgave 5
      String spillernavn = input.next();
      Spiller spiller = new VeiValgSpillerRobot(start, spillernavn, terreng, robot);

      System.out.println("Hei, " + spiller.hentNavn() + " ! Velg antall trekk for dette spillet.");

      Random r = new Random();
      int antallTrekk = r.nextInt(10);
      System.out.println("Hei, " + spiller.hentNavn() + " ! Antall trekk for dette spillet: " + antallTrekk);

      int teller = 0;
      while (teller != antallTrekk){
        System.out.println("----------------------------------");
        System.out.println("Tekk : "+ (teller +1));
        if (spiller != null){
          spiller.nyttTrekk();
          teller ++;
        }


      }
      System.out.println("-------------------------------");
      System.out.println("-------------------------------");
      System.out.println("Resultat for dette spillet: ");

      System.out.println("Spiller : " + spiller.hentNavn());
      System.out.println("Din formue: " + spiller.hentFormue());
      System.out.println("Antall trekk: " + antallTrekk);

    }
  }

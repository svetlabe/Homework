import java.util.*;
import java.util.Scanner;
import java.io.*;


public class Test{

  public static void main(String [] args){


    Terreng ter = new VeiValgTerreng();

    LinkedList<Sted> stedliste1 = ter.hentStedListe();
    System.out.println(ter.hentStedListe().get(1));
    ArrayList<Sted> nyliste = ter.hentStedListe().get(1).hentUtganger();
    for(Sted s : nyliste){
      System.out.println(s);
    }
    //System.out.println(ter.hentStedListe().get(1).hentUtgang());
    }



}

import java.util.Scanner;
import java.util.Random;

public class SpillKontrollVeiValg {


  public void startSpillKontroll(){
    Scanner scanner = new Scanner(System.in);
    String[] valgarray = new String []{"0", "1"};

    Spill spill;
    System.out.println("Hvem skal spille: 0 - robot, 1 - bruker?");
    int valg;
    valg = lesInput();
    while(check(valgarray, valg)!= true){
      System.out.println("Velg mellom 0 og 1 for aa starte spillet.");
      valg = lesInput();
    }
    if(valg == 0){
      spill = new SpillRobotVeiValg();
      spill.startSpill();
    }
    if (valg == 1){
      spill = new SpillBrukerVeiValg();
      spill.startSpill();
    }

  }

  public static  int lesInput(){
    Scanner scanner1 = new Scanner(System.in);
    int valg1;
    try{

      valg1 = Integer.parseInt(scanner1.next());
    }
    catch(NumberFormatException ex){
      System.out.println("Proev igjen");
      valg1 = Integer.parseInt(scanner1.next());
    }
    return valg1;
  }

  private static boolean check(String[] valg, int input){
    boolean kontroll = false;
    int lengde = valg.length;
    int [] nyarray = new int[lengde];
    for(int i =0; i<lengde; i++){
      nyarray[i]=i;

    }
    for(int j=0; j< nyarray.length; j++ ){
      if (j == input){
        kontroll = true;}
    }

    return kontroll;
  }
}

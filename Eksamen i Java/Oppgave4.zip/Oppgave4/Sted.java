import java.util.ArrayList;

public class Sted{

  protected Sted neste;
  protected String beskrivelse;
  protected Skattkiste skattkiste;

  public Sted(String beskr){
    beskrivelse = beskr;

  }

  public void settUtgang(Sted nesteSted){
    neste = nesteSted;
  }

  public void settSkattKiste(Skattkiste kiste){
    skattkiste = kiste;
  }

  public Skattkiste hentSkattKiste(){
    return skattkiste;
  }

  public Sted gaaVidere(){
    return neste;
  }

  public String toString(){
    return beskrivelse;
  }

  public Sted hentUtgang(){
    return neste;
  }

// maatte lage denne metoden som jeg overskriver i VeiValgSted
// ellers virket programmet ikke og fikk melding om at kompilator ikke kunne finne symbol (metoden)
  public ArrayList<Sted> hentUtganger(){
    return null;
  }




}

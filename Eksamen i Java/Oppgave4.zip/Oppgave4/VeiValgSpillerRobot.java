import java.util.ArrayList;

public class VeiValgSpillerRobot extends SpillerRobot{

  private String spoersmaal1 = "Hvor vil du gaa?";
  private String[] velgUtgang = new String[]{"Gaa frem", "Gaa til hoeyre", "Gaa til venstre", "Gaa ingen sted"};
  private ArrayList<Sted> utganger;





  public VeiValgSpillerRobot(Sted start, String navn, Terreng ter1, Robot r){
    super(start, navn, ter1, r);
    currentSted = start;
    utganger = currentSted.hentUtganger();

  }


  public void utgangMeny(){

    int utgangValg = robot.beOmKommando(spoersmaal1, velgUtgang);


    if (utgangValg == 0){
      currentSted = utganger.get(0);


    }

    if (utgangValg == 1){
      currentSted = utganger.get(1);
    }

    if(utgangValg == 2){
      currentSted = utganger.get(2);
    }

    if (utgangValg == 3){
      return;
    }

  }

  @Override
  public void nyttTrekk(){
    robot.giStatus("");
    robot.giStatus( currentSted.toString()); // viser hvor vi er i spillet
    robot.giStatus(currentSted.hentSkattKiste().kisteStatus()); // viser status paa kiste(tom eller ikke)


    // robot proever aa selge gjenstand

                                        // hvis spiller vil selge
      if(ryggsekk.kiste.size()> 0 ){                        // hvis ryggsekk ikke er tom
        Gjenstand tattUtAvSekken = ryggsekk.taUtAvRyggsekk(); // tar ut gjenstand med hoeyest verdi
        currentSted.hentSkattKiste().leggTil(tattUtAvSekken); // legger til kiste med  salgsverdi
        formue += tattUtAvSekken.hentPris();
        robot.giStatus("Gratulerer! Du har solgt " + tattUtAvSekken);
        robot.giStatus("Din formue er: " + formue);
        robot.giStatus("Ryggsekken inneholder: ");
        robot.giStatus(ryggsekk.visInnholdKiste());
                                                   // ber om valg2 (ta fra kiste, gaa videre eller avslutt)

      } else {
        robot.giStatus("Du kan ikke selge nå. Ryggsekken er tom.");


    }

    // robot proever aa kjoepe
    if(currentSted!= null){
      if(currentSted.hentSkattKiste().kiste.size() > 0 ){
        Gjenstand fantSkatt = currentSted.hentSkattKiste().taUt();
        ryggsekk.leggTil(fantSkatt);
        robot.giStatus("Gratulerer! Du fant " + fantSkatt);
        robot.giStatus("Ryggsekken inneholder: ");
        robot.giStatus(ryggsekk.visInnholdKiste());

        utgangMeny();                        // ber om valg(bli igjen paa stedet, gaa videre eller avslutt)

      }else {
        System.out.println("Du er ikke på et sted i spillet.");

      }
      utgangMeny(); // gaar til neste sted




    }

  }







}

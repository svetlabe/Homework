import java.util.ArrayList;
/*
Jeg tolker oppgaven slik at neste kan vi beholde og lage to utganger til som er
koblet til steder valgt tilfeldig.

Valg av datastruktur:
jeg har valgt array både for utganger og for beskrivelser, fordi antall er definert i oppgaven.
*/
public class VeiValgSted extends Sted {

  private ArrayList<Sted> utganger;
  private String [] beskrivelser;



  public VeiValgSted(String beskrivelse){
    super(beskrivelse);
    beskrivelser = new String[]{"neste", "hoeyere", "venstre"};
    utganger = new ArrayList<Sted>();

  }

// neste er alleredere definert i Sted, trenger to utganger til
  public void settUtgang(Sted utgang){
    utganger.add(utgang);
  }


  @Override
  public ArrayList<Sted> hentUtganger(){
    return utganger;
  }

  @Override
  public Sted gaaVidere(){
    if(utganger.size()>0){
      Sted neste = utganger.get(0);
    }
    return neste;
  }


}

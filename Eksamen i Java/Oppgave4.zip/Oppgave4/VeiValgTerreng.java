import java.util.*;
import java.util.Scanner;
import java.io.*;

public class VeiValgTerreng extends Terreng {
  private LinkedList<Sted> stedlisteVeiValg;

  public VeiValgTerreng(){
    stedlisteVeiValg = new LinkedList<>();
    lagTerreng(lesFraFil());
    settUtganger();

  }


  @Override
  protected void lagTerreng(ArrayList<String> navn){
    for(String n: navn){
      if (n != null){
        Sted nySted1 = new VeiValgSted(n);
        Skattkiste nykiste1 = new Skattkiste();
        nykiste1.fyllSkattkiste();
        nySted1.settSkattKiste(nykiste1);
        if (stedlisteVeiValg!= null){
          stedlisteVeiValg.add(nySted1);
        }

      }

    }

  }

  @Override
  protected void settUtganger(){
    if (stedlisteVeiValg != null){
      for(int i = 0; i < stedlisteVeiValg.size()-1; i++){
        if (stedlisteVeiValg.get(i) != null){
          Random randomindeks = new Random();
          int indeks1 = randomindeks.nextInt(stedlisteVeiValg.size());
          int indeks2 = randomindeks.nextInt(stedlisteVeiValg.size());
          stedlisteVeiValg.get(i).settUtgang(stedlisteVeiValg.get(i+1));  // setter neste
          stedlisteVeiValg.get(i).settUtgang(stedlisteVeiValg.get(indeks1)); // setter kobling til tilfeldige steder
          stedlisteVeiValg.get(i).settUtgang(stedlisteVeiValg.get(indeks2));
        } else System.out.println("Dette stedet er tomt " + i);

      }
    }



  }

  @Override
  public Sted hentStart(){
    Random r = new Random();
    int tillfeldigSted1 = r.nextInt(stedlisteVeiValg.size());
    Sted start1 = stedlisteVeiValg.get(tillfeldigSted1);
    return start1;
  }

  @Override
  public LinkedList<Sted> hentStedListe(){
    return stedlisteVeiValg;
  }
}

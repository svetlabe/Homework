abstract class Spill{

  abstract void startSpill();
}

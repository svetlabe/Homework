public class SpillerRobot extends Spiller{

  /*
Reglene er samme som i tidligere oppgaver, men jeg har redusert antall valg etter at roboten har valgt aa ta gjenstand fra kisten
robot skal gaa videre etter at den har tatt noe fra kiste

  */

  protected Robot robot;
  protected Skattkiste ryggsekk;
  protected String[] valg1 = new String[]{"Selge en gjenstand fra ryggsekken.", "Ta skatt fra kisten.", "Gaa videre."};
  protected String[] valg2 = new String []{"Ta skatt fra kisten.", "Gaa videre."};
  protected String spoersmaal = "Hva vil du gjøre nå?";
  protected Sted currentSted;
  protected Sted nesteSted;


  public SpillerRobot(Sted start,  String navn, Terreng ter, Robot r){
    super(start, navn, ter);
    robot = r;
    ryggsekk = new Skattkiste();    // oppretter tom ryggsekk
    nesteSted = startSted.gaaVidere();
    currentSted = startSted;

  }

  @Override
  public void nyttTrekk(){
    robot.giStatus("");
    robot.giStatus( currentSted.toString()); // viser hvor vi er i spillet
    robot.giStatus(currentSted.hentSkattKiste().kisteStatus()); // viser status paa kiste(tom eller ikke)


    int kommando1 = robot.beOmKommando(spoersmaal, valg1); // ber om valg (selge, ta fra kiste, gaa)


    if(kommando1 == 0){
                                     // hvis robot vil selge
      if(ryggsekk.kiste.size()> 0 ){                        // hvis ryggsekk ikke er tom
        Gjenstand tattUtAvSekken = ryggsekk.taUtAvRyggsekk(); // tar ut gjenstand med hoeyest verdi
        currentSted.hentSkattKiste().leggTil(tattUtAvSekken); // legger til kiste med  salgsverdi
        formue += tattUtAvSekken.hentPris();
        robot.giStatus("Jeg har solgt " + tattUtAvSekken);
        robot.giStatus("Min formue er: " + formue);
        robot.giStatus("Ryggsekken inneholder: ");
        robot.giStatus(ryggsekk.visInnholdKiste());
        valg2();                                            // ber om valg2 (ta fra kiste, gaa videre )

      } else {
        robot.giStatus("Ops! Jeg kan ikke selge nå. Ryggsekken er tom.");
        kommando1 = robot.beOmKommando(spoersmaal, valg1); // spilleren faa en sjanse til valg1
      }
    }
    if(kommando1 == 1){
                                // brukeren vil ta fra kiste

      if(currentSted!= null){
        if(currentSted.hentSkattKiste().kiste.size() > 0 ){
          Gjenstand fantSkatt = currentSted.hentSkattKiste().taUt();
          ryggsekk.leggTil(fantSkatt);
          robot.giStatus("Jeg fant " + fantSkatt);
          robot.giStatus("Ryggsekken inneholder: ");
          robot.giStatus(ryggsekk.visInnholdKiste());
          currentSted = nesteSted;
          nesteSted = currentSted.gaaVidere(); // robot gaar til neste sted)

        }else {
          System.out.println("Jeg har mistet terreng.");
        }
      }


    }

    if (kommando1 == 2){  // velger aa gaa videre

      currentSted = nesteSted;
      nesteSted = currentSted.gaaVidere();



    }

  }

  public void valg2(){
    int kommando2 = robot.beOmKommando(spoersmaal, valg2); // ta kra kisten eller gaa videre
    if(kommando2 == 0){

      if(currentSted.hentSkattKiste().kiste.size() > 0 ){
        Gjenstand fantSkatt2 = currentSted.hentSkattKiste().taUt();
        ryggsekk.leggTil(fantSkatt2);
        robot.giStatus("Jeg fant " + fantSkatt2);
        robot.giStatus("Ryggsekken inneholder: ");
        robot.giStatus(ryggsekk.visInnholdKiste());
      }else{
        robot.giStatus("Kisten er tom. Jeg maa gaa videre.");
        currentSted = nesteSted;
        nesteSted = currentSted.gaaVidere();
      }
      currentSted = nesteSted;
      nesteSted = currentSted.gaaVidere();  // etter at roboten har tatt gjenstand fra kisten, gaar den videre
    }
    if(kommando2 == 1){

      currentSted = nesteSted;
      nesteSted = currentSted.gaaVidere();
    }

  }


}

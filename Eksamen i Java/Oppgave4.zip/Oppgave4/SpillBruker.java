import java.util.*;


// Her er det spill med brukeren som spiller.
// for aa spille med robot, se fil SpillRobot

public class SpillBruker extends Spill{

  @Override
  public void startSpill(){
    Terreng terreng = new Terreng();
    Sted start = terreng.hentStart();
    Scanner input = new Scanner(System.in);
    Terminal terminal = new Terminal(input);
    System.out.println("----------------------------------");
    System.out.println("----------------------------------");
    System.out.println("Spillet startet! Velg et navn. ");
    String spillernavn = input.next();
    Spiller spiller1 = new SpillerBruker(start, spillernavn, terreng, terminal);

    System.out.println("Hei, " + spiller1.hentNavn() + " ! Velg antall trekk for dette spillet.");

    int antallTrekk = lesInput();


    int teller = 0;
    while (teller != antallTrekk){
      System.out.println("----------------------------------");
      System.out.println("Tekk : "+ (teller +1));
      spiller1.nyttTrekk();

      teller ++;
    }
    System.out.println("-------------------------------");
    System.out.println("-------------------------------");
    System.out.println("Resultat for dette spillet: ");
    System.out.println("Spiller : " + spiller1.hentNavn());
    System.out.println("Din formue: " + spiller1.hentFormue());
    System.out.println("Antall trekk: " + antallTrekk);


  }

  public int lesInput(){
    Scanner scanner1 = new Scanner(System.in);
    int valg1 = -1;

    while(valg1 < 0){
      try{
        valg1 = scanner1.nextInt();

      }
      catch(InputMismatchException ex){
        System.out.println("Proev igjen. Tast inn et tall ");
        scanner1.next();
      }
    }


    return valg1;
  }
}

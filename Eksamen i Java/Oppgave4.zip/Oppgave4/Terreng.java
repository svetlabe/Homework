/*
Her maatte jeg endre lesFraFil() og lage ny metode for aa lage terreng med objekter Sted,
Terreng skal fremdeles inneholde LinkedListmed objekter ac type Sted, mens VeiValgTerreng skal inneholde liste metode
objekter av type VeiValgSted

*/

import java.util.*;
import java.util.Scanner;
import java.io.*;


public class Terreng{
  protected LinkedList<Sted> stedliste;

  public Terreng(){
    stedliste = new LinkedList<>();
    lagTerreng(lesFraFil());
    settUtganger();
  }

  protected ArrayList<String> lesFraFil(){
    ArrayList<String> stedsnavn = new ArrayList<>();
    File f = new File("steder.txt");
    Scanner fil = null;
    try {
      fil = new Scanner(f);
    } catch (FileNotFoundException e) {
      System.out.println("Filen er ikke funnet!");
    }

    String linje = "";
    while(fil.hasNextLine()){
      linje = fil.nextLine();
      stedsnavn.add(linje);


    }
    return stedsnavn;

  }

  protected void lagTerreng(ArrayList<String> navn){
    for(String n: navn){
      Sted nySted = new Sted(n);
      Skattkiste nykiste = new Skattkiste();
      nykiste.fyllSkattkiste();
      nySted.settSkattKiste(nykiste);
      stedliste.add(nySted);

    }

  }

//-- setter referanser til neste sted for alle steder --
//-- terreng er gjort til syklisk ----------------------
    protected void settUtganger(){
      if (stedliste.size()>0){
        for(int i = 0; i < stedliste.size()-1; i++){
          stedliste.get(i).settUtgang(stedliste.get(i+1));
        }
        stedliste.get(stedliste.size()-1).settUtgang(stedliste.getFirst());
      }


    }

//---- henter tilfeldig sted -----------------------------
    public Sted hentStart(){
      Random r = new Random();
      int tillfeldigSted = r.nextInt(stedliste.size());
      Sted start = stedliste.get(tillfeldigSted);
      return start;
    }

    public LinkedList<Sted> hentStedListe(){
      return stedliste;
    }



}

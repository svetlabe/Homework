/*
Siden vi har to typer av spillere, velger aa lager klassen Spiller som abstract
Menneskelig bruker skal spille gjennom klasse SpillerBruker, mens robot - SpillerRobot
*/

abstract class Spiller{

  protected String navn;
  protected Sted startSted;
  protected Terreng terreng;
  protected int formue = 0;

  public Spiller (Sted start, String navn, Terreng ter){
    startSted = start;
    this.navn = navn;
    terreng = ter;

  }

  abstract void nyttTrekk();



  public int hentFormue(){
    return formue;

  }

  public String hentNavn(){
    return navn;

  }



}

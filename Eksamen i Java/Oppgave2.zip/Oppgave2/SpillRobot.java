import java.util.Scanner;
import java.util.Random;

public class SpillRobot extends Spill{

  @Override
  public void startSpill(){
    String[] robotnavn = new String[]{"Robot", "Robot1", "Robot2","R"};
    Terreng terreng = new Terreng();
    Sted start = terreng.hentStart();
    Scanner input = new Scanner(System.in);
    Terminal terminal = new Terminal(input);
    Robot robot = new Robot();
    System.out.println("----------------------------------");
    System.out.println("----------------------------------");
    System.out.println("Spillet startet! Velg et navn. ");
    Random randomnavn = new Random();
    int tilfelignavn = randomnavn.nextInt(robotnavn.length);
    String spillernavn = robotnavn[tilfelignavn];
    Spiller spiller2 = new SpillerRobot(start, spillernavn, terreng, robot);

    Random r = new Random();
    int antallTrekk2 = r.nextInt(100);
    System.out.println("Hei, " + spiller2.hentNavn() + " ! Antall trekk for dette spillet: " + antallTrekk2);
    int teller = 0;
    while (teller != antallTrekk2){
      System.out.println("----------------------------------");
      System.out.println("Tekk : "+ (teller +1));

      spiller2.nyttTrekk();
      teller ++;
    }
    System.out.println("-------------------------------");
    System.out.println("-------------------------------");
    System.out.println("Resultat for dette spillet: ");

    System.out.println("Spiller : " + spiller2.hentNavn());
    System.out.println("Din formue: " + spiller2.hentFormue());
    System.out.println("Antall trekk: " + antallTrekk2);

  }
}

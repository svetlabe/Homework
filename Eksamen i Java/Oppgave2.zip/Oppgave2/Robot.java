import java.util.Random;

public class Robot implements Brukergrensesnitt{


  @Override
  public void giStatus(String status){
    System.out.println(status);
  }



  @Override
  public int beOmKommando(String spoersmaal, String[] alternativer){
    Random r = new Random();
    int indeks = 0;
    System.out.println();
    if (spoersmaal != null){
      System.out.println(spoersmaal);
    }

    for (int i = 0; i< alternativer.length; i++){
      if (alternativer[i] != null){
        System.out.println(indeks + ": " + alternativer[i]);
        indeks ++;
      }

    }
    int valg = r.nextInt(alternativer.length);
    System.out.println();
    if (alternativer[valg] != null){
      System.out.println("Jeg velger: " + alternativer[valg]);
    }


    return valg;

  }
}

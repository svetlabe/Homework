import java.util.*;
/*
Dette er hovedprogram
man faar valg av spilleren
Dersom man velger robot, blir objekt av type SpillRobot laget og kalt paa metoden startSpill()
spillet starter. Robot kan velge antallTrekk mellom 0 og 100. Dette kan endres i SpillRobot.

Maatte lage noen metoder i denne filen for aa sikre riktig input
*/

public class SpillKontroll{

  public static void main(String [] args){
    Scanner scanner = new Scanner(System.in);
    String[] valgarray = new String []{"0", "1"};

    Spill spill;
    System.out.println("Hvem skal spille: 0 - robot, 1 - bruker?");
    int valg;
    valg = lesInput();
    while(check(valgarray, valg)!= true){
      System.out.println("Velg mellom 0 og 1 for aa starte spillet.");
      valg = lesInput();
    }


    if(valg == 0){
      spill = new SpillRobot();
      spill.startSpill();
    } else if (valg == 1){
      spill = new SpillBruker();
      spill.startSpill();}



  }

  public static  int lesInput(){
    Scanner scanner1 = new Scanner(System.in);
    int valg1 = -1;

    while(valg1 < 0){
      try{
        valg1 = scanner1.nextInt();

      }
      catch(InputMismatchException ex){
        System.out.println("Proev igjen. Tast inn et tall ");
        scanner1.next();
      }
    }


    return valg1;
  }

  private static boolean check(String[] valg, int input){
    boolean kontroll = false;
    int lengde = valg.length;
    int [] nyarray = new int[lengde];
    for(int i =0; i<lengde; i++){
      nyarray[i]=i;

    }
    for(int j=0; j< nyarray.length; j++ ){
      if (j == input){
        kontroll = true;}
    }

    return kontroll;
  }
}

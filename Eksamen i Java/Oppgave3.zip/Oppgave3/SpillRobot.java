
import java.util.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class SpillRobot extends Spill{

  public void startSpill()
  {
/*
Jeg har endret programmet slik at Robot velger navn selv fra String [] med navn

Siden vi skal bruke traa kun en gang, er det greit aa bruke anonimous class
Anonimous class er beskrevet i pensumboken s.480
brukte ogsaa Udemy-video for inspirasjon.

*/

  Application.launch();

  }

// start-metode ligner litt paa run(). Plasserer alle operasjonene hit.
  @Override
  public void start (Stage teater){

    Terreng terreng = new Terreng();
    Sted start = terreng.hentStart();
    Scanner input = new Scanner(System.in);
    Robot robot = new Robot();
    String[] robotnavn = new String[]{"Robot", "Robot1", "Robot2","R"};
    System.out.println("----------------------------------");
    System.out.println("----------------------------------");
    System.out.println("Spillet startet! Velg et navn. ");
    Random randomnavn = new Random();
    int tilfelignavn = randomnavn.nextInt(robotnavn.length);
    String spillernavn = robotnavn[tilfelignavn];

    Spiller spiller2 = new SpillerRobot(start, spillernavn, terreng, robot);

    Random r = new Random();
    int antallTrekk2 = r.nextInt(100);
    System.out.println("Hei, " + spiller2.hentNavn() + " ! Antall trekk for dette spillet: " + antallTrekk2);
    int teller = 0;
    while (teller != antallTrekk2){
      System.out.println("----------------------------------");
      System.out.println("Tekk : "+ (teller +1));

      spiller2.nyttTrekk();
      teller ++;
    }

    System.out.println("-------------------------------");
    System.out.println("-------------------------------");
    Thread t = new Thread(){
      @Override
      public void run()
      {
        try {
          Thread.sleep(5000);
        }catch (InterruptedException e){
          e.printStackTrace();
        }
        Platform.exit();
    }
  };
  t.start();

// GUI
    Button avslutt = new Button("Avslutt");
    avslutt.setOnAction(new Avslutt());
    Text resultat = new Text("Resultat for dette spillet:");
    Text spillernavnText = new Text("Spiller: " + spiller2.hentNavn());
    Text formue = new Text("Formue: ");
    Text antall = new Text("");
    antall.setText(""+ spiller2.hentFormue());
    HBox antallFormue = new HBox();
    antallFormue.getChildren().addAll(formue, antall);
    Text trekkTekst = new Text(" Antall trekk i spillet: ");
    Text antallTrekkGui = new Text("");
    antallTrekkGui.setText(""+ antallTrekk2);
    HBox trekk = new HBox();
    trekk.getChildren().addAll(trekkTekst, antallTrekkGui);
    VBox kulisser = new VBox();
    kulisser.getChildren().addAll(resultat,spillernavnText, antallFormue, trekk, avslutt);
    Scene scene = new Scene(kulisser);
    teater.setScene(scene);
    teater.setTitle("Spill med Robot");
    teater.show();
  }

  public class Avslutt implements EventHandler<ActionEvent>{
    @Override
    public void handle(ActionEvent event){
      Platform.exit();
    }


  }
}

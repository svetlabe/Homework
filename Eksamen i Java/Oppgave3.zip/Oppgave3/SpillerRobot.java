public class SpillerRobot extends Spiller{

  /*
  Reglene for robot:
  -- robot maa gjennomfoere antall trekk som den velger
  -- antall trekk er  plukket tilfeldig, intervall kan justeres i Spill.java
  -- det er samme regel for salg av gjenstander, gjenstand med hoeyest verdi plikkes ut

  */

  private Robot robot;
  private Skattkiste ryggsekk;
  private String[] valg1 = new String[]{"Selge en gjenstand fra ryggsekken.", "Ta skatt fra kisten.", "Gaa videre."};
  String[] valg2 = new String []{"Ta skatt fra kisten.", "Gaa videre."};
  String[] valg3 = new String []{"Bli igjen på dette stedet, her er mange skatter igjen","Gaa videre."};
  private String spoersmaal = "Hva vil du gjøre nå?";
  private Sted currentSted;
  private Sted nesteSted;


  public SpillerRobot(Sted start,  String navn, Terreng ter, Robot r){
    super(start, navn, ter);
    robot = r;
    ryggsekk = new Skattkiste();    // oppretter tom ryggsekk
    nesteSted = startSted.gaaVidere();
    currentSted = startSted;

  }

  @Override
  public void nyttTrekk(){
    robot.giStatus("");
    robot.giStatus( currentSted.toString()); // viser hvor vi er i spillet
    robot.giStatus(currentSted.hentSkattKiste().kisteStatus()); // viser status paa kiste(tom eller ikke)


    int kommando1 = robot.beOmKommando(spoersmaal, valg1); // ber om valg (selge, ta fra kiste, gaa, avslutt)


    if(kommando1 == 0){
                                     // hvis spiller vil selge
      if(ryggsekk.kiste.size()> 0 ){                        // hvis ryggsekk ikke er tom
        Gjenstand tattUtAvSekken = ryggsekk.taUtAvRyggsekk(); // tar ut gjenstand med hoeyest verdi
        currentSted.hentSkattKiste().leggTil(tattUtAvSekken); // legger til kiste med  salgsverdi
        formue += tattUtAvSekken.hentPris();
        robot.giStatus("Jeg har solgt " + tattUtAvSekken);
        robot.giStatus("Min formue er: " + formue);
        robot.giStatus("Ryggsekken inneholder: ");
        robot.giStatus(ryggsekk.visInnholdKiste());
        valg2();                                            // ber om valg2 (ta fra kiste, gaa videre eller avslutt)

      } else {
        robot.giStatus("Ops! Jeg kan ikke selge nå. Ryggsekken er tom.");
        kommando1 = robot.beOmKommando(spoersmaal, valg1); // spilleren faa en sjanse til valg1
      }
    }
    if(kommando1 == 1){
                                // brukeren vil ta fra kiste

      if(currentSted!= null){
        if(currentSted.hentSkattKiste().kiste.size() > 0 ){
          Gjenstand fantSkatt = currentSted.hentSkattKiste().taUt();
          ryggsekk.leggTil(fantSkatt);
          robot.giStatus("Jeg fant " + fantSkatt);
          robot.giStatus("Ryggsekken inneholder: ");
          robot.giStatus(ryggsekk.visInnholdKiste());

          valg3();                          // ber om valg(bli igjen paa stedet, gaa videre eller avslutt)


        }else {
          System.out.println("Jeg har mistet terreng.");
        }
      }


    }

    if (kommando1 == 2){

      currentSted = nesteSted;
      nesteSted = currentSted.gaaVidere();



    }

  }

  public void valg2(){
    int kommando2 = robot.beOmKommando(spoersmaal, valg2);
    if(kommando2 == 0){

      if(currentSted.hentSkattKiste().kiste.size() > 0 ){
        Gjenstand fantSkatt2 = currentSted.hentSkattKiste().taUt();
        ryggsekk.leggTil(fantSkatt2);
        robot.giStatus("Jeg fant " + fantSkatt2);
        robot.giStatus("Ryggsekken inneholder: ");
        robot.giStatus(ryggsekk.visInnholdKiste());
      }else{
        robot.giStatus("Kisten er tom. Jeg maa gaa videre.");
        currentSted = nesteSted;
        nesteSted = currentSted.gaaVidere();
      }
      valg3();
    }
    if(kommando2 == 1){

      currentSted = nesteSted;
      nesteSted = currentSted.gaaVidere();
    }

  }


  public void valg3(){
    int kommando3 = robot.beOmKommando(spoersmaal, valg3);
    if (kommando3 == 0){

      return;
    } else if (kommando3 == 1){

      currentSted = nesteSted;
      nesteSted = currentSted.gaaVidere();
    }

  }
}

public class Gjenstand implements Comparable<Gjenstand>{
  private String beskrivelse;
  private int verdi;
/*
Gjenstand er gjord sammenligdbar for å kunne finne gjenstand med høyest verdi
når man tar ut gjenstand fra ryggsekken
*/
  public Gjenstand(String beskr, int pris){
    beskrivelse = beskr;
    verdi = pris;
  }

  public String toString(){
    return beskrivelse + " med verdi på " + verdi;
  }

  public int hentPris(){
    return verdi;
  }

  public void endrePris(int tillegg){
    verdi += tillegg;
  }
  @Override
    public int compareTo(Gjenstand annen) {
      Integer dennePris = new Integer(this.hentPris());
      Integer annenPris = new Integer(annen.hentPris());
      if (dennePris.compareTo(annenPris) > 0) {
          return 1;
      }
      else if (dennePris.compareTo(annenPris) < 0) {
          return -1;
      }
      else return 0;
  }

}

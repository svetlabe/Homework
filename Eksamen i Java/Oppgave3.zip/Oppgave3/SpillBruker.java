import java.util.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

/*
1. Her er det spill med brukeren som spiller,
for aa spille med robot, se fil SpillRobot

2. GUI: jeg brukte fremgangsmåten som ble gjennomgaatt paa repitisjonskurset.

3. lsget anonimous class Thread siden vi bruker traa kun en gang, plasserte den
i metoden void start() foer selve vinduet skal aapnes (se SpillRobot for flere kommentarer).
*/


public class SpillBruker extends Spill{

  public void startSpill(){

    Application.launch();

    }

  @Override
  public void start (Stage teater){
    Terreng terreng = new Terreng();
    Sted start = terreng.hentStart();
    Scanner input = new Scanner(System.in);
    Terminal terminal = new Terminal(input);
    System.out.println("----------------------------------");
    System.out.println("----------------------------------");
    System.out.println("Spillet startet! Velg et navn. ");
    String spillernavn = input.next();
    Spiller spiller1 = new SpillerBruker(start, spillernavn, terreng, terminal);

    System.out.println("Hei, " + spiller1.hentNavn() + " ! Velg antall trekk for dette spillet.");

    int antallTrekk = lesInput();


    int teller = 0;
    while (teller != antallTrekk){
      System.out.println("----------------------------------");
      System.out.println("Tekk : "+ (teller +1));
      spiller1.nyttTrekk();

      teller ++;
    }
    System.out.println("-------------------------------");
    System.out.println("-------------------------------");
  // man kan ogsaa lage egen klasse som implements Runnable
    Thread t = new Thread(){
      @Override
      public void run()
      {
        try {
          Thread.sleep(5000);

        }catch (InterruptedException e){
          e.printStackTrace();
        }
        Platform.exit();
    }
    };
    t.start();

    //GUI

    Button avslutt = new Button("Avslutt");
    avslutt.setOnAction(new Avslutt());
    Text resultat = new Text("Resultat for dette spillet:");
    Text spillernavnText = new Text("Spiller: " + spiller1.hentNavn());
    Text formue = new Text("Formue: ");
    Text antall = new Text("");
    antall.setText(""+ spiller1.hentFormue());
    HBox antallFormue = new HBox();
    antallFormue.getChildren().addAll(formue, antall);
    VBox kulisser = new VBox();
    kulisser.getChildren().addAll(resultat,spillernavnText, antallFormue, avslutt);
    Scene scene = new Scene(kulisser);
    teater.setScene(scene);
    teater.setTitle("Spill med brukeren");
    teater.show();



  }

  private boolean check(String[] valg, int input){
    boolean kontroll = false;
    int lengde = valg.length;
    int [] nyarray = new int[lengde];
    for(int i =0; i<lengde; i++){
      nyarray[i]=i;

    }
    for(int j=0; j< nyarray.length; j++ ){
      if (j == input){
        kontroll = true;}
    }

    return kontroll;
  }

  public int lesInput(){
    Scanner scanner1 = new Scanner(System.in);
    int valg1 = -1;

    while(valg1 < 0){
      try{
        valg1 = scanner1.nextInt();

      }
      catch(InputMismatchException ex){
        System.out.println("Proev igjen. Tast inn et tall ");
        scanner1.next();
      }
    }
    return valg1;
  }

  public class Avslutt implements EventHandler<ActionEvent>{
    @Override
    public void handle(ActionEvent event){
      Platform.exit();
    }
  }

}

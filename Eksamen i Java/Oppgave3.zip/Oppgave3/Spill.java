
import javafx.application.Application;
import javafx.stage.Stage;

abstract class Spill extends Application{

  abstract void startSpill();
  @Override
  public void start(Stage teater){};

}

import java.util.*;

public class Terminal implements Brukergrensesnitt{

  Scanner scanner;

  public Terminal(Scanner sc){
    scanner = sc;
  }

  @Override
  public void giStatus(String status){
    if (status != null){
      System.out.println(status);
    }



  }



  @Override
  public int beOmKommando(String spoersmaal, String[] alternativer){
    int valg = -1;
    System.out.println();
    int indeks = 0;

    if (spoersmaal != null){
      System.out.println(spoersmaal);
    }

    for (int i = 0; i< alternativer.length; i++){
      if(alternativer[i] != null){
        System.out.println(indeks + ": " + alternativer[i]);
        indeks ++;
      }

    }
    while(valg < 0){
      try{
        valg = scanner.nextInt();

      }
      catch(InputMismatchException ex){
        System.out.println("Proev igjen. Tast inn et tall ");
        scanner.next();
      }
    }

    return valg;

  }


}
